# CEFF-GO
CEFF-GO sera une activité accessible durant les portes ouvertes du CEFF Industrie. Ce projet est réalisé durant le TIB de la classe 3_3 maturité multilingue.
